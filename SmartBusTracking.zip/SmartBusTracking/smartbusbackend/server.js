const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
const DB_FILE = path.join(__dirname, 'smartbus.db');

// SQLite setup
const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');

db.prepare(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE,
  password TEXT,
  role TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  message TEXT,
  time TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS location (
  id INTEGER PRIMARY KEY,
  lat REAL,
  lng REAL,
  updated_at TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
)`).run();

// Seed default users
const seedUsers = [
  { username: 'admin', password: 'admin123', role: 'admin' },
  { username: 'parent', password: 'parent123', role: 'parent' }
];
const insertUser = db.prepare('INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)');
seedUsers.forEach(u => insertUser.run(u.username, u.password, u.role));

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files from Smartbusfrontend directory
app.use(express.static(path.join(__dirname, '../Smartbusfrontend')));

// Root route to serve index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../Smartbusfrontend/index.html'));
});

// Routes (SQLite-backed)
const insertNotif = db.prepare('INSERT INTO notifications (message, time) VALUES (?, ?)');
const getNotifs = db.prepare('SELECT message, time FROM notifications ORDER BY id');
const getLocation = db.prepare('SELECT lat, lng FROM location WHERE id = 1');
const upsertLocation = db.prepare('INSERT OR REPLACE INTO location (id, lat, lng, updated_at) VALUES (1, ?, ?, ?)');
const getMeta = db.prepare('SELECT value FROM meta WHERE key = ?');
const setMeta = db.prepare('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)');
const getUser = db.prepare('SELECT role FROM users WHERE username = ? AND password = ?');

app.post('/send-notification', (req, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string' || message.trim().length === 0) {
    return res.status(400).json({ error: 'Invalid message' });
  }

  insertNotif.run(message.trim(), new Date().toISOString());
  res.json({ success: true });
});

app.get('/notifications', (req, res) => {
  const rows = getNotifs.all();
  res.json(rows);
});

app.get('/location', (req, res) => {
  const row = getLocation.get();
  if (!row) return res.json({ lat: 12.9716, lng: 77.5946 });
  res.json({ lat: row.lat, lng: row.lng });
});

app.get(['/bus-status', '/status'], (req, res) => {
  const row = getMeta.get('busStatus');
  res.json({ status: row ? row.value : 'On Time' });
});

app.post('/update-location', (req, res) => {
  const { lat, lng } = req.body;
  if (typeof lat !== 'number' || typeof lng !== 'number') {
    return res.status(400).json({ error: 'Latitude and longitude must be numbers' });
  }

  upsertLocation.run(lat, lng, new Date().toISOString());
  res.json({ success: true });
});

app.post('/emergency', (req, res) => {
  setMeta.run('busStatus', 'Emergency');
  insertNotif.run('Emergency reported by driver', new Date().toISOString());
  res.json({ success: true });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Username and password are required' });
  }

  const row = getUser.get(username, password);
  if (!row) return res.status(401).json({ success: false, error: 'Invalid credentials' });

  res.json({ success: true, role: row.role });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});