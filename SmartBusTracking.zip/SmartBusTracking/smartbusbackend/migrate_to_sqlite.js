const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const DATA_FILE = path.join(__dirname, 'data.json');
const DB_FILE = path.join(__dirname, 'smartbus.db');

function loadData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {
    console.error('Failed to read data.json', e);
    return { notifications: [], location: { lat: 12.9716, lng: 77.5946 }, busStatus: 'On Time' };
  }
}

const data = loadData();
const db = new Database(DB_FILE);

db.pragma('journal_mode = WAL');

db.prepare(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE,
  password TEXT,
  role TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  message TEXT,
  time TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS location (
  id INTEGER PRIMARY KEY,
  lat REAL,
  lng REAL,
  updated_at TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT
)`).run();

// Seed users if missing
const seedUsers = [
  { username: 'admin', password: 'admin123', role: 'admin' },
  { username: 'parent', password: 'parent123', role: 'parent' }
];

const insertUser = db.prepare('INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)');
const insertNotif = db.prepare('INSERT INTO notifications (message, time) VALUES (?, ?)');
const insertLocation = db.prepare('INSERT OR REPLACE INTO location (id, lat, lng, updated_at) VALUES (1, ?, ?, ?)');
const insertMeta = db.prepare('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)');

const tx = db.transaction(() => {
  seedUsers.forEach(u => insertUser.run(u.username, u.password, u.role));

  (data.notifications || []).forEach(n => {
    insertNotif.run(n.message, n.time || new Date().toISOString());
  });

  if (data.location) {
    insertLocation.run(data.location.lat, data.location.lng, new Date().toISOString());
  }

  insertMeta.run('busStatus', data.busStatus || 'On Time');
});

tx();

console.log('Migration to SQLite completed. DB:', DB_FILE);
db.close();
