// Configurable server URL
const SERVER_URL = "http://localhost:3000";

// Utility function for API calls with error handling
async function apiCall(endpoint, options = {}) {
  try {
    const res = await fetch(`${SERVER_URL}${endpoint}`, options);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(`API error for ${endpoint}:`, err);
    throw err;
  }
}

// Example: Load notifications (can be reused in other pages)
async function loadNotifications(listElementId) {
  try {
    const data = await apiCall('/notifications');
    const list = document.getElementById(listElementId);
    list.innerHTML = "";
    data.forEach(n => {
      const li = document.createElement("li");
      const date = new Date(n.time);
      const timeStr = isNaN(date.getTime()) ? "Invalid date" : date.toLocaleString();
      li.textContent = `${n.message} (${timeStr})`;
      list.appendChild(li);
    });
  } catch (err) {
    document.getElementById(listElementId).innerHTML = "<li>Failed to load.</li>";
  }
}